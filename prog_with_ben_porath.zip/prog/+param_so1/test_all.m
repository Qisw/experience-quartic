function test_all(gNo, setNo)

disp('Testing parameter functions');

param_so1.directories(true, gNo, setNo);
param_so1.directories(false, gNo, setNo);


end