function param_check(paramS, cS)
% Check parameters
% -------------------------------------------

% update later +++++
% if ~isequal(size(paramS.tEndow_tscM),  [cS.demogS.ageRetire, cS.nSchool, cS.nCohorts])
%    error_so1('Invalid size of time endowments', cS);
% end




%% Skill prices

% update later +++++
% if ~v_check(paramS.logWNodeM, 'f', [cS.nSchool, length(cS.spNodeV) - length(cS.spNodeZeroV)], -5, 5, [])
%    error_so1('Invalid')
% end



end