function cS = const_data_so1(gNo)

cS = const_so1(gNo, 1);
cS = const_so1(gNo, cS.dataSetNo);

end