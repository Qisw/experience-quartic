function test_results(gNo, setNo)



end