classdef TestLH
   enumeration
      Monday, Tuesday, Wednesday, Thursday, Friday
   end
   
end