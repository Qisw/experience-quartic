function cal_features(cS)
% Show calibration features
% ---------------------------------------------


disp('----  Calibration features:');
disp(['  Description:  ', cS.setStr]);


end