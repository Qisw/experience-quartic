function bYearV = byear_from_age(ageV, yearV, cS)

bYearV = yearV - ageV + cS.demogS.ageInBirthYear;

end