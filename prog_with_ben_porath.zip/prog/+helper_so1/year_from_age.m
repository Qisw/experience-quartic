function yearV = year_from_age(ageV, bYearV, ageInBirthYear)

yearV = bYearV + ageV - ageInBirthYear;

end