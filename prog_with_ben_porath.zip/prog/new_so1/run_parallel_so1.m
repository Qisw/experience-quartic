function run_parallel_so1(nRuns, saveHistory, gNo, setNo)
%{
Kure command for this: kure_parallel_so1
%}

iniglob_so1;
cal_parallel_so1(nRuns, saveHistory, gNo, setNo)


end