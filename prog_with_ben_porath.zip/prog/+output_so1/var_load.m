function [outV, success] = var_load(varNo, cS)
% Load a MAT variable
%{
Use var_load_so1 interface instead
%}
% ----------------------------------------------

[outV, success] = var_load_so1(varNo, cS);

end